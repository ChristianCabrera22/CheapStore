# CheapStore | Pre-entrega 3 

Bienvenido a mi repositorio, este trabajo está en desarrollo para el curso web de CoderHouse..

Este sitio fue evolucionando desde la primer pre-entrega, se trabajo con herramientas vistas en el curso adaptando detalles del sitio para que sea responsive en cualquier dispositivo (tamaño de ventana).

Se trabajó con Frameworks bootstrap, animaciones y componentes tomados de la web.
También se utilizaron algunos códigos js para dar más funcionalidad al sitio.

Las paginas aun están en desarrollo, aplicando conceptos vistos en clase se irán completando...

Christian Cabrera ... comision: 33040
